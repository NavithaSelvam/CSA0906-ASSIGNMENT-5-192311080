CREATE DATABASE IF NOT EXISTS transport_test;
USE transport_test;
CREATE TABLE IF NOT EXISTS bus_pass (
  pass_id  VARCHAR(10) PRIMARY KEY,
  reg_no   VARCHAR(12) NOT NULL,
  name     VARCHAR(50) NOT NULL,
  route_no INT NOT NULL,
  amount   DOUBLE NOT NULL
);
